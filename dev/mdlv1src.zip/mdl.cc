/* source files for MedDLe, a quake model editor by Brian Martin */
#include "mdl.h"

// our good old mdl file data (it's extern)
struct MDL_FILE mdl;

// use this stuff for command line options
#define NUM_CFG_OPTIONS 3
char *cfg_option[NUM_CFG_OPTIONS] = {"mode","driver","progspath"};
char driver[128], progspath[128];
unsigned char pal[256*3];

//GrContext *BitMapContext;

//----------------------------------------------------------------------

int main (int argc, char *argv[])
{
    FILE *in, *out, *qpal;
    char *in_filename,*out_filename,*filename;
    char str[256];
    char ch;
    short cur_key;
    short draw_3d=1;
    short draw_triangles=0;
    short draw_vertices=0;
    short import_file=0;
    short export_file=0;
    short show_info=0;
    unsigned i,j,k,l;
    unsigned p1,p2,p3,p4;
    int video_mode=0;
    int update=0;
    int refresh=0;
    int oldx,oldy,oldr,oldl,oldm;
    int selected=0;
    int ontopof=0;
    int selectedx, selectedy, selectedindex;
    int madechanges=0;
    int loop;
    int goto_3d=0;
    float zoom_factor=2;

    // set default values
    driver[0]=NULL;
    progspath[0]=NULL;

    clrscr();
    printf("MedDLe by Brian Martin version 1.0\n\n");

    // get config file settings
    if((in=fopen("mdl.cfg","rt"))==NULL)
    {
        fprintf(stderr,"Can't open mdl.cfg, using defaults... \n");
        fprintf(stderr,"Things probably won't work. Hit a key. \n");
        getch();
    }
    else
    {
        fprintf(stderr,"Reading mdl.cfg ...\n");
        ch=0;
        do
        {
            fscanf(in,"%s", str);
            if(feof(in)) break;
            if(str[0]=='#') {while(fgetc(in)!=0x0A);}
            else
            {
                k=0;
                for(i=0; i<NUM_CFG_OPTIONS; i++)
                {
                    j=0;
                    while(*(cfg_option[i]+j)!=NULL)
                    {
                        k=i+1;
                        if(str[j]!=*(cfg_option[i]+j)) {k=0;break;}
                        j++;
                    }
                    if(k!=0) break;
                }
                if(k==0) fprintf(stderr,"Don't understand option \"%s\" in config file. \n",str);
                else
                {
                    fscanf(in,"%s", str);
                    switch (k)
                    {
                        case 1: video_mode=atoi(str); fprintf(stderr," - setting video mode = %d\n",video_mode); break;
                        case 2: strcpy(driver,str); fprintf(stderr," - setting driver = %s\n",driver);break;
                        case 3: strcpy(progspath,str); fprintf(stderr," - setting progspath = %s\n",progspath);break;
                    }
                }
            }
        }while(!feof(in));
        fclose(in);
    }


    // get command line options
    for (argv++, argc--; argc && **argv == '-'; argv++, argc--)
    {
        if ((*argv)[1] == 'e' && argc-- > 1)
        {
            out_filename = *++argv;
            export_file=1;
        }
        else if ((*argv)[1] == 'i' && argc-- > 1)
        {
            in_filename = *++argv;
            import_file=1;
        }

        else if ((*argv)[1] == 'm' && argc-- > 1)
            video_mode= atoi( *(++argv));

        else if ((*argv)[1] == '2')
            draw_3d = 0;

        else if ((*argv)[1] == 's')
            show_info = 1;

        else if ((*argv)[1] == 'h')
        {
            fprintf(stderr, "Usage: mdl [-h] [-2] [-s] [-e <file.bmp>] [-i <file.bmp>] [-m #] file.mdl \n");
            fprintf(stderr, "       -h  -- help screen\n");
            fprintf(stderr, "       -2  -- start in 2d view\n");
            fprintf(stderr, "       -s  -- show header information\n");
            fprintf(stderr, "       -e  -- extract BMP file\n");
            fprintf(stderr, "       -i  -- insert BMP file\n");
            fprintf(stderr, "       -m  -- video mode\n");
            fprintf(stderr, "              0 = 320x200 (default)\n");
            fprintf(stderr, "              1-4 hi res modes\n");
            exit(1);
        }
        else
        {
            fprintf(stderr, "What is %s?  mdl -h will help you", *argv);
            exit(1);
        }
    }

    if (argc > 0)
        filename = *argv;
    else
    {
        fprintf(stderr, "mdl -h will help you", *argv);
        exit(1);
    }

    // read in mdl file

    strcpy(str,progspath);
    strcat(str,filename);
    if((in=fopen(str,"rb"))==NULL)
    {
        printf("can't open mdl file \"%s\" ...exiting\n",str);
        exit(1);
    }
    read_mdl(in, &mdl);
    strcpy(mdl.filename,filename);
    fclose(in);

    // setup 3d stuff
    setup_3d_data(&mdl);


    // read in quake colors
    BG_OpenPalette("mdl.pal",pal);
    // intiate graphics mode
    BG_GraphicsMode(driver,video_mode);
    // change the screen colors to the quake palette
    BG_SetPalette(pal);
    // initiate mouse
    BG_InitMouse();
    BG_MouseStatus();
    oldx=BG_MouseX;
    oldy=BG_MouseY;
    // intiate math tables
    BG_InitMath();

    BG_ClearScreen(0);
    while(1)
    {
        if(draw_3d==1)
        {
            if(mdl_3d(&mdl)==0) break;
            else draw_3d=0;
        }
        else
        {
            if(mdl_2d(&mdl)==0) break;
            else draw_3d=1;
        }
    }

    BG_TextMode();

    clrscr();



    delete mdl.bitmap;
    delete mdl.vertex;
    delete mdl.triangle;

    for(j=0; j<mdl.num_frames;  j++) delete mdl.frame[j].v;
    delete mdl.frame;
    delete_3d_data(&mdl);

//  fprintf(stderr,"\nMedDLe v0.2 1996\n  by Brian Martin\n  brian@phyast.pitt.edu\n");
//  fprintf(stderr,"\n\"Tell'n you all the ZombyTroof...\n   Here I'm is...\n      the ZombyWoof!\" -fz\n\n");
//  getch();
    return(0);
}


