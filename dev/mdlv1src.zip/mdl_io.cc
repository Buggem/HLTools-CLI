/* source files for MedDLe, a quake model editor by Brian Martin */
#include "mdl.h"


void read_mdl(FILE *in, MDL_FILE *m)
{
    int i,j,k;

    fread(&mdl.filetype,4,1,in);
    fread(&mdl.version,4,1,in);
    fread(&mdl.xscale,4,1,in);
    fread(&mdl.yscale,4,1,in);
    fread(&mdl.zscale,4,1,in);
    fread(&mdl.xoffset,4,1,in);
    fread(&mdl.yoffset,4,1,in);
    fread(&mdl.zoffset,4,1,in);
    fread(&mdl.radius,4,1,in);
    fread(&mdl.f1,4,1,in);
    fread(&mdl.f2,4,1,in);
    fread(&mdl.f3,4,1,in);
    fread(&mdl.num_items,4,1,in);
    fread(&mdl.bitmapw,4,1,in);
    fread(&mdl.bitmaph,4,1,in);
    fread(&mdl.num_vertices,4,1,in);
    fread(&mdl.num_triangles,4,1,in);
    fread(&mdl.num_frames,1,4,in);
    fread(&mdl.blank,1,4,in);


    mdl.bitmap = new (unsigned char)[mdl.bitmapw*mdl.bitmaph*mdl.num_items];

    for(k=0;k<mdl.num_items;k++)
    {
        fseek(in,4,SEEK_CUR);

        for(j=0;j<mdl.bitmaph;j++)
        {
            for(i=0;i<mdl.bitmapw;i++)
            {
                fread(mdl.bitmap+(i+mdl.bitmapw*(j+k*mdl.bitmaph)),1,1,in);
            }
        }
    }

    mdl.vertex = new (unsigned)[mdl.num_vertices*3];

    for(i=0;i<mdl.num_vertices;i++)
    {
        fread(mdl.vertex+i*3,4,1,in);
        fread(mdl.vertex+i*3+1,4,1,in);
        fread(mdl.vertex+i*3+2,4,1,in);
    }

    mdl.triangle = new (unsigned)[mdl.num_triangles*4];

    for(i=0;i<mdl.num_triangles;i++)
    {
        fread(mdl.triangle+i*4,4,1,in);
        fread(mdl.triangle+i*4+1,4,1,in);
        fread(mdl.triangle+i*4+2,4,1,in);
        fread(mdl.triangle+i*4+3,4,1,in);

    }

    mdl.frame = new (struct vframe)[mdl.num_frames];

    for(j=0; j<mdl.num_frames;  j++)
    {
//      fread(mdl.frame[j].head,1,12,in);

        fread(&mdl.frame[j].blank,4,1,in);
        fread(mdl.frame[j].minbound,1,3,in);

        fread(&mdl.frame[j].unknown1,1,1,in);
        fread(mdl.frame[j].maxbound,1,3,in);
        fread(&mdl.frame[j].unknown2,1,1,in);


        mdl.frame[j].v = new (unsigned char)[mdl.num_vertices*4];

        for(i=0;i<mdl.num_vertices;i++)
        {
            fread(mdl.frame[j].v+i*4  ,1,1,in);
            fread(mdl.frame[j].v+i*4+1,1,1,in);
            fread(mdl.frame[j].v+i*4+2,1,1,in);
            fread(mdl.frame[j].v+i*4+3,1,1,in);
        }
    }



}



void write_mdl(FILE *out, MDL_FILE *m)
{
    unsigned i,j,k;
    unsigned empty=0;

    fwrite(mdl.filetype,4,1,out);
    fwrite(&mdl.version,4,1,out);
    fwrite(&mdl.xscale,4,1,out);
    fwrite(&mdl.yscale,4,1,out);
    fwrite(&mdl.zscale,4,1,out);
    fwrite(&mdl.xoffset,4,1,out);
    fwrite(&mdl.yoffset,4,1,out);
    fwrite(&mdl.zoffset,4,1,out);
    fwrite(&mdl.radius,4,1,out);
    fwrite(&mdl.f1,4,1,out);
    fwrite(&mdl.f2,4,1,out);
    fwrite(&mdl.f3,4,1,out);

    fwrite(&mdl.num_items,4,1,out);
    fwrite(&mdl.bitmapw,4,1,out);
    fwrite(&mdl.bitmaph,4,1,out);
    fwrite(&mdl.num_vertices,4,1,out);
    fwrite(&mdl.num_triangles,4,1,out);
    fwrite(&mdl.num_frames,4,1,out);
    fwrite(&mdl.blank,4,1,out);

    for(k=0;k<mdl.num_items;k++)
    {
        fputc(0,out);
        fputc(0,out);
        fputc(0,out);
        fputc(0,out);

        for(j=0;j<mdl.bitmaph;j++)
        {
            for(i=0;i<mdl.bitmapw;i++)
            {
                fputc(mdl.bitmap[(i+mdl.bitmapw*(j+k*mdl.bitmaph))],out);
            }
        }
    }


    for(i=0;i<mdl.num_vertices;i++)
    {
        fwrite(mdl.vertex+i*3L,4,1,out);
        fwrite(mdl.vertex+i*3L+1L,4,1,out);
        fwrite(mdl.vertex+i*3L+2L,4,1,out);

    }

    for(i=0;i<mdl.num_triangles;i++)
    {
        fwrite(mdl.triangle+i*4L,4,1,out);
        fwrite(mdl.triangle+i*4L+1L,4,1,out);
        fwrite(mdl.triangle+i*4L+2L,4,1,out);
        fwrite(mdl.triangle+i*4L+3L,4,1,out);
    }


    for(j=0; j<mdl.num_frames;  j++)
    {

        fwrite(&mdl.frame[j].blank,4,1,out);
        fwrite(mdl.frame[j].minbound,1,3,out);
        fwrite(&mdl.frame[j].unknown1,1,1,out);
        fwrite(mdl.frame[j].maxbound,1,3,out);
        fwrite(&mdl.frame[j].unknown2,1,1,out);
//      fwrite(mdl.frame[j].head,1,12,out);
        for(i=0;i<mdl.num_vertices;i++)
        {
            fwrite(mdl.frame[j].v+i*4,1,1,out);
            fwrite(mdl.frame[j].v+i*4+1,1,1,out);
            fwrite(mdl.frame[j].v+i*4+2,1,1,out);
            fwrite(mdl.frame[j].v+i*4+3,1,1,out);
        }
    }

}


void setup_3d_data(MDL_FILE *m)
{
    int blocks;
    int i,j,k;
    BG_3pt vect1, vect2;
    int maxn;

    blocks=mdl.num_frames;

    block= new (BG_Block)[blocks];
    if(block==NULL) exit(1);

    for(i=0; i<blocks; i++)
    {
        block[i].num_pts=mdl.num_vertices;
        block[i].ptlist=new (BG_3pt)[block[i].num_pts+8];
        block[i].nindex=new (unsigned char)[block[i].num_pts];
        if(block[i].ptlist==NULL) exit(1);
        maxn=0;
        // read all points
        for(j=0;j<block[i].num_pts;j++)
        {
            block[i].ptlist[j].x=mdl.xscale*(mdl.frame[i].v[j*4])+mdl.xoffset;//+mdl.f1;//+mdl.f1)+mdl.xoffset;
            block[i].ptlist[j].y=mdl.yscale*(mdl.frame[i].v[j*4+1])+mdl.yoffset;//+mdl.f2;//+mdl.f2)+mdl.yoffset;
            block[i].ptlist[j].z=mdl.zscale*(mdl.frame[i].v[j*4+2])+mdl.zoffset;//+mdl.f3;//+mdl.f3)+mdl.zoffset;
            block[i].nindex[j]=mdl.frame[i].v[j*4+3];
        }
        block[i].ptlist[block[i].num_pts].x= mdl.xscale*mdl.frame[i].minbound[0]+mdl.xoffset;
        block[i].ptlist[block[i].num_pts].y= mdl.yscale*mdl.frame[i].minbound[1]+mdl.yoffset;
        block[i].ptlist[block[i].num_pts].z= mdl.zscale*mdl.frame[i].minbound[2]+mdl.zoffset;

        block[i].ptlist[block[i].num_pts+1].x= mdl.xscale*mdl.frame[i].maxbound[0]+mdl.xoffset;
        block[i].ptlist[block[i].num_pts+1].y= mdl.yscale*mdl.frame[i].maxbound[1]+mdl.yoffset;
        block[i].ptlist[block[i].num_pts+1].z= mdl.zscale*mdl.frame[i].maxbound[2]+mdl.zoffset;

        block[i].ptlist[block[i].num_pts+2].x= mdl.xscale*mdl.frame[i].minbound[0]+mdl.xoffset;
        block[i].ptlist[block[i].num_pts+2].y= mdl.yscale*mdl.frame[i].minbound[1]+mdl.yoffset;
        block[i].ptlist[block[i].num_pts+2].z= mdl.zscale*mdl.frame[i].maxbound[2]+mdl.zoffset;

        block[i].ptlist[block[i].num_pts+3].x= mdl.xscale*mdl.frame[i].minbound[0]+mdl.xoffset;
        block[i].ptlist[block[i].num_pts+3].y= mdl.yscale*mdl.frame[i].maxbound[1]+mdl.yoffset;
        block[i].ptlist[block[i].num_pts+3].z= mdl.zscale*mdl.frame[i].minbound[2]+mdl.zoffset;

        block[i].ptlist[block[i].num_pts+4].x= mdl.xscale*mdl.frame[i].minbound[0]+mdl.xoffset;
        block[i].ptlist[block[i].num_pts+4].y= mdl.yscale*mdl.frame[i].maxbound[1]+mdl.yoffset;
        block[i].ptlist[block[i].num_pts+4].z= mdl.zscale*mdl.frame[i].maxbound[2]+mdl.zoffset;

        block[i].ptlist[block[i].num_pts+5].x= mdl.xscale*mdl.frame[i].maxbound[0]+mdl.xoffset;
        block[i].ptlist[block[i].num_pts+5].y= mdl.yscale*mdl.frame[i].minbound[1]+mdl.yoffset;
        block[i].ptlist[block[i].num_pts+5].z= mdl.zscale*mdl.frame[i].minbound[2]+mdl.zoffset;

        block[i].ptlist[block[i].num_pts+6].x= mdl.xscale*mdl.frame[i].maxbound[0]+mdl.xoffset;
        block[i].ptlist[block[i].num_pts+6].y= mdl.yscale*mdl.frame[i].minbound[1]+mdl.yoffset;
        block[i].ptlist[block[i].num_pts+6].z= mdl.zscale*mdl.frame[i].maxbound[2]+mdl.zoffset;

        block[i].ptlist[block[i].num_pts+7].x= mdl.xscale*mdl.frame[i].maxbound[0]+mdl.xoffset;
        block[i].ptlist[block[i].num_pts+7].y= mdl.yscale*mdl.frame[i].maxbound[1]+mdl.yoffset;
        block[i].ptlist[block[i].num_pts+7].z= mdl.zscale*mdl.frame[i].minbound[2]+mdl.zoffset;



        block[i].num_sides=mdl.num_triangles;
        block[i].side=new (BG_Side)[block[i].num_sides];
        if(block[i].side==NULL) exit(1);

        for(j=0;j<block[i].num_sides; j++)
        {
            block[i].side[j].num_pts=3;
            if((block[i].side[j].pt=new(word)[3])==NULL) exit(1);

            block[i].side[j].pt[0]=mdl.triangle[j*4L+1L];
            block[i].side[j].pt[1]=mdl.triangle[j*4L+2L];
            block[i].side[j].pt[2]=mdl.triangle[j*4L+3L];

            vect1=BG_SubtractPts(&block[i].ptlist[block[i].side[j].pt[1]],&block[i].ptlist[block[i].side[j].pt[0]]);
            vect2=BG_SubtractPts(&block[i].ptlist[block[i].side[j].pt[2]],&block[i].ptlist[block[i].side[j].pt[1]]);
            block[i].side[j].normal=BG_CrossProduct(&vect2,&vect1);
            BG_Normalize(&block[i].side[j].normal);
        }
    }
}

void delete_3d_data(MDL_FILE *m)
{
    int i,j,blocks;

    blocks=mdl.num_frames;

    for(i=0; i<blocks; i++)
    {
        delete block[i].ptlist;

        for(j=0;j<block[i].num_sides; j++)
        {
            delete block[i].side[j].pt;
        }
        delete block[i].side;
    }

    delete block;

}
