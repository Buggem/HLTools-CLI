/* source files for MedDLe, a quake model editor by Brian Martin */
// Mouse Routines
extern int                      BG_MouseLeft,
                                BG_MouseRight,
                                BG_MouseMiddle;
extern int                      BG_MouseX,
                                BG_MouseY;

extern void BG_InitMouse();
extern void BG_MouseShow(void);
extern void BG_MouseHide(void);
extern void BG_MouseStatus();
extern void BG_MouseRange(int x1, int y1, int x2, int y2);
extern void BG_MouseToXY(int x, int y);
extern void BG_MouseSpeed(int s);
extern void BG_MousePointing(void);
extern void BG_MouseCrossHairs(void);

#ifdef USEGRX





#endif
