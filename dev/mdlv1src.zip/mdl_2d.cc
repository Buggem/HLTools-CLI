/* source files for MedDLe, a quake model editor by Brian Martin */
#include "mdl.h"

GrContext *BitMapContext;


int mdl_2d(MDL_FILE *m)
{
    FILE *out;
    int i,j,k,l;
    unsigned p1,p2,p3,p4;
    int ontopof=0;
    int selectedx, selectedy, selectedindex;
    int madechanges=0;
    int loop;
    int draw_triangles=1,draw_vertices=1;
    int draw_3d=0;
    int goto_3d=0;
    int zoom_factor=2;

    BG_ClearScreen(0);

        BitMapContext = GrCreateContext(mdl.bitmapw,mdl.bitmaph*mdl.num_items,NULL,NULL);
        GrSetContext(BitMapContext);
        for(k=0;k<mdl.num_items;k++)
        {
            for(j=0;j<mdl.bitmaph;j++)
            {
                for(i=0;i<mdl.bitmapw;i++)
                {
                    BG_PutPixel(i,j+k*mdl.bitmaph,mdl.bitmap[i+(j+k*mdl.bitmaph)*mdl.bitmapw]);
                }
            }
        }
        GrSetContext(NULL);
//      for(i=0;i<256;i++) BG_PutPixel(i,0,i);
        GrBitBlt(NULL,0,0,BitMapContext,0,0,mdl.bitmapw-1,mdl.bitmaph-1,GrWRITE);
        BG_MouseStatus();

        int update=1;
        int refresh=1;
        int oldx=BG_MouseX,oldy=BG_MouseY,oldr=BG_MouseRight,oldl=BG_MouseLeft;
        BG_MouseShow();
        loop=1;
        char cur_key;
        int selected=0;
        while(loop)
        {
            BG_MouseStatus();

            if(kbhit())
            {
                if((cur_key=getch())==0x0) cur_key=getch();
             // cur_key=getch();
                switch(cur_key)
                {
                case 27:            loop=0; draw_3d=0; break;
                case '3':           loop=0; draw_3d=1; break;
                case 'w':case 'W':  if(draw_triangles==0)draw_triangles=1;
                                    else draw_triangles=0; break;
                case 'v':case 'V':  if(draw_vertices==0)draw_vertices=1;
                                    else draw_vertices=0; break;
                case 's':case 'S':
                        BG_Text("Saving",0,0,250,0);

                        if((out=fopen(mdl.filename,"wb"))==NULL)
                        {
                            fprintf(stderr,"can't open mdl file... bye\n");
                            exit(1);
                        }
                        rewind(out);
                        write_mdl(out, &mdl);
                        fclose(out);
                        break;

                case ARROW_DOWN:    if(BG_MouseY<(BG_ScreenHeight-1)) {BG_MouseY++; BG_MouseToXY(BG_MouseX,BG_MouseY); BG_MouseStatus();} break;
                case ARROW_UP:      if(BG_MouseY>0) {BG_MouseY--;BG_MouseToXY(BG_MouseX,BG_MouseY); BG_MouseStatus();} break;
                case ARROW_LEFT:    if(BG_MouseX>0) {BG_MouseX--;BG_MouseToXY(BG_MouseX,BG_MouseY); BG_MouseStatus();} break;
                case ARROW_RIGHT:   if(BG_MouseX<(BG_ScreenWidth-1)) {BG_MouseX++; BG_MouseToXY(BG_MouseX,BG_MouseY); BG_MouseStatus();} break;
                }
                update=1;
                refresh=1;
            }

            if((BG_MouseLeft==1)||(BG_MouseX!=oldx)||(BG_MouseY!=oldy))
            {
                oldx=BG_MouseX;
                oldy=BG_MouseY;
                oldr=BG_MouseLeft;
                update=1;
            }
            if(update==1)
            {
                BG_MouseHide();

                if(BG_MouseLeft==1)
                {
                    if(selected==1)
                    {
                        refresh=1;
                        BG_PutPixel(mdl.vertex[selectedindex*3+1],mdl.vertex[selectedindex*3+2],mdl.bitmap[mdl.vertex[selectedindex*3+1]+mdl.vertex[selectedindex*3+2]*mdl.bitmapw]);
                        if(mdl.vertex[selectedindex*3]==1)
                            BG_PutPixel(mdl.bitmapw/2+mdl.vertex[selectedindex*3+1],mdl.vertex[selectedindex*3+2],mdl.bitmap[mdl.bitmapw/2+mdl.vertex[selectedindex*3+1]+mdl.vertex[selectedindex*3+2]*mdl.bitmapw]);

                        if((mdl.vertex[selectedindex*3]==1)&&(BG_MouseX>mdl.bitmapw/2))
                        {
                            mdl.vertex[selectedindex*3+1]=BG_MouseX-mdl.bitmapw/2;
                            mdl.vertex[selectedindex*3+2]=BG_MouseY;
                        }
                        else
                        {
                            mdl.vertex[selectedindex*3+1]=BG_MouseX;
                            mdl.vertex[selectedindex*3+2]=BG_MouseY;
                        }
                    }
                }
                else selected=0;
                if(refresh)
                GrBitBlt(NULL,0,0,BitMapContext,0,0,mdl.bitmapw-1,mdl.num_items*(mdl.bitmaph-1),GrWRITE);

                if(draw_triangles)
                {
                    int x1,x2,x3;
                    for(i=0;i<mdl.num_triangles;i++)
                    {
                        p1=mdl.triangle[i*4+1];
                        p2=mdl.triangle[i*4+2];
                        p3=mdl.triangle[i*4+3];
                        p4=mdl.triangle[i*4];

                        x1=x2=x3=0;
                        if((mdl.vertex[3*p1]==1)&&(p4==0)) x1=mdl.bitmapw/2;
                        if((mdl.vertex[3*p2]==1)&&(p4==0)) x2=mdl.bitmapw/2;
                        if((mdl.vertex[3*p3]==1)&&(p4==0)) x3=mdl.bitmapw/2;

                        BG_Line(mdl.vertex[p1*3+1]+x1,mdl.vertex[p1*3+2],mdl.vertex[p2*3+1]+x2,mdl.vertex[p2*3+2],8);
                        BG_Line(mdl.vertex[p2*3+1]+x2,mdl.vertex[p2*3+2],mdl.vertex[p3*3+1]+x3,mdl.vertex[p3*3+2],8);
                        BG_Line(mdl.vertex[p3*3+1]+x3,mdl.vertex[p3*3+2],mdl.vertex[p1*3+1]+x1,mdl.vertex[p1*3+2],8);

                    }
                }

                for(i=0;i<mdl.num_vertices;i++)
                {
                    if(mdl.vertex[i*3]!=1)
                    {
                        if((BG_MouseX==mdl.vertex[i*3+1])&&(BG_MouseY==mdl.vertex[i*3+2]))
                        {
                            if(selected==0)
                            {
                            ontopof=1;
                            if(BG_MouseLeft){selectedindex=i;selected=1;}
                            }
                        }
                        else ontopof=0;

                    }
                    else
                    {
                        if((BG_MouseX==mdl.bitmapw/2+mdl.vertex[i*3+1])&&(BG_MouseY==mdl.vertex[i*3+2])
                        ||(BG_MouseX==mdl.vertex[i*3+1])&&(BG_MouseY==mdl.vertex[i*3+2]))
                        {
                            if(selected==0)
                            {
                            ontopof=1;
                            if(BG_MouseLeft){selectedindex=i;selected=1; }
                            }
                        }
                        else ontopof=0;

                    }

                    if(draw_vertices)
                    {
                        BG_PutPixel(mdl.vertex[i*3+1],mdl.vertex[i*3+2],254-4*ontopof);
                        if(mdl.vertex[i*3]==1)
                        BG_PutPixel(mdl.bitmapw/2+mdl.vertex[i*3+1],mdl.vertex[i*3+2],254-4*ontopof);
                    }


                }

                BG_MouseShow();
                update=0;
                refresh=0;
            }

        }


    GrDestroyContext(BitMapContext);

    

    if(draw_3d==0) return 0;
    else return 1;


}
