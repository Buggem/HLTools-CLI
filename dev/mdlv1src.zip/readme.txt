------ meddle source code read me ---------------

WARNING: USE THIS SOURCE AT YOUR OWN RISK! THE AUTHOR IS NOT
RESPONSIBLE FOR ANY LOSS OF DATA OR OTHER DAMAGE CAUSED BY USE
OF THIS SOURCE CODE!

------ ramblings ------

I haven't look at the bulk of meddle's source since a few 
weeks after the qtest, but some tweaking was done in march i think. 
I will warn you that it isn't a pretty sight.
Keep in mind that most of it was written in about a week.

I kept telling my self that I would clean it up and release it.
Well I am releasing it.... but the clean up is not there.
You may find it hard to follow. That is too bad. 

The version of source is slightly different from the released
version of meddle (1.0). This is because I added some gouraurd
shading, the ability to take screen shots, and a faster 2d to 3d
transition. And I fixed the mouse control in 2d mode a little I 
think.

My intention was to create a simple GUI and make a 3d editor. Well
I have a simple GUI, but its source is just as ugly. But I did learn
a little about making a GUI. SO... I'm not gonna do a DOS MedDLe 
editor with a nice GUI because it was taking too long, but if someone
needs some suggestions on gui developement, I may be able to suggest
a few things if you are new to this sort of stuff. 

Also I hope someone ports this to linux, since I've had a few
questions about that...

LASTLY, there are some bad programming techniques in this source as 
well as some errors which really don't hurt anything. Too bad.

------ the files ------

This is all i'm gonna say about the contents of the files, 
but you can email me if you have a question:

makefile    ::  it's the make file (duh)
mdl.pal     ::  the palette for quake
mdl.cfg     ::  config file for program
mdl.cc      ::  the main program, reads command line, cfg file, etc
mdl_io.cc   ::  read/write mdl file, set up 3d data
mdl_2d.cc   ::  All the 2D editing and displaying things 
mdl_3d.cc   ::  All the 3D editing and displaying things
bg_grx.cc   ::  My graphics routines converted to grx with a lot of
                unused and redundant stuff. A lot of 3dgpl stuff pasted
                in there.
bg_mouse.cc ::  my mouse routines (yuck)
bg.h        ::  header file for graphics
bg_3d.h     ::  more 3d junk, this was merged with bg.h into bg_grx.h
                but I can't find that build, it must be at home. 
bg_mouse.h  ::  header file for mouse stuff
mdl.h       ::  header file for main program
mdl.exe     ::  a working version!
cwsdpmi.exe ::  dpmi environment

I bet most of you are reading this because you want to add texture
mapping to something. Well, here is some help. You'll have to look
at stuff towards the end of bg_grx.cc, you'll need to cut and 
paste alot. It doesn't do proper volume clipping either. You also
should look at mdl_3d.cc since that is where the meat is. It is 
completely un-optimized. If you don't understand the 3d format, it
is similar to that found in the book by Allen Watt ( i think that's
his name) on 3d graphics. In the main loop I convert all points
to the eyeball (camara) coordinate system, sort the sides, back
face removal, then draw them. That's it.

The texturing routine is a little different from 3dgpl, it just
uses bilinear mapping instead of perspective corrected (i.e. i just
hacked the gouraurd shading routine). 

Gouraurd shading can be easily added to the texture mapping (like
quake), the code only needs a little modification and you have to
dig up the color map from quake.

Lastly, I included 3ds2mdl.cc which kinda works. It is a program
which reads 3ds files and saves them as an mdl file. It only reads
one object and is in the experimental stage. I did make some quake 
models with it though. You just have to keep the number of polys low.
And use MedDLe to do the mapping. The makefile for it is called 
makefile.3ds. This may be of some help to someone. Figuring out the
3ds file format wasn't the easiest thing to do with the docs I had,
(and I didn't have 3ds!), so if you release a converter of some sort,
please give me some credit. The hard part is done, you just need to
fix some things.   

------ compiling ------

You should be able to compile this stuff as is with DJGPPv2 and
GRXv2. I will tell you right now that I am one of the best source
code thieves. But I do give credit where credit is due. Most of the 
3d code was adapted from 3dgpl (get it at x2ftp.oulu.fi) as stated in
the meddle read me. If your good enough to understand the stuff your 
stealing, then fine, it saves time. That's why meddle source is here.
If you can make heads or tails out of it, it may help you make 
your editor. Take what you want, just give credit to whom you feel
deserves it.

note: the 3ds2mdl might not compile (or even work). But it should, I just
haven't tested it for some time and it might be an old version.

oh, and just type 'make' to make the program. :)

-------- LAST WORD ------

The meddle project IS NOT DEAD. It's just that I don't have much time
now a days. I am learning vc++, and will continue MedDLe in windows.
I also plan to make it a real 3d editor and may make it a brush
editor as well. If time permits there will be some quake map editing
features like monster placement and stuff. For you dos and linux
guys, I give you this code :)

-----------------------
brian martin
the zombywoof

brian@phyast.pitt.edu
www.phyast.pitt.edu/~brian

