// 3ds2mdl.cc
// hope this converts 3ds files to mdl files


#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>

typedef struct BG_3pt{
  double x,y,z;
  };

BG_3pt norm_table[162]={
{-0.525731,0.000000,0.850651},
{-0.442863,0.238856,0.864188},
{-0.295242,0.000000,0.955423},
{-0.309017,0.500000,0.809017},
{-0.162460,0.262866,0.951056},
{0.000000,0.000000,1.000000},
{0.000000,0.850651,0.525731},
{-0.147621,0.716567,0.681718},
{0.147621,0.716567,0.681718},
{0.000000,0.525731,0.850651},
{0.309017,0.500000,0.809017},
{0.525731,0.000000,0.850651},
{0.295242,0.000000,0.955423},
{0.442863,0.238856,0.864188},
{0.162460,0.262866,0.951056},
{-0.681718,0.147621,0.716567},
{-0.809017,0.309017,0.500000},
{-0.587785,0.425325,0.688191},
{-0.850651,0.525731,0.000000},
{-0.864188,0.442863,0.238856},
{-0.716567,0.681718,0.147621},
{-0.688191,0.587785,0.425325},
{-0.500000,0.809017,0.309017},
{-0.238856,0.864188,0.442863},
{-0.425325,0.688191,0.587785},
{-0.716567,0.681718,-0.147621},
{-0.500000,0.809017,-0.309017},
{-0.525731,0.850651,0.000000},
{0.000000,0.850651,-0.525731},
{-0.238856,0.864188,-0.442863},
{0.000000,0.955423,-0.295242},
{-0.262866,0.951056,-0.162460},
{0.000000,1.000000,0.000000},
{0.000000,0.955423,0.295242},
{-0.262866,0.951056,0.162460},
{0.238856,0.864188,0.442863},
{0.262866,0.951056,0.162460},
{0.500000,0.809017,0.309017},
{0.238856,0.864188,-0.442863},
{0.262866,0.951056,-0.162460},
{0.500000,0.809017,-0.309017},
{0.850651,0.525731,0.000000},
{0.716567,0.681718,0.147621},
{0.716567,0.681718,-0.147621},
{0.525731,0.850651,0.000000},
{0.425325,0.688191,0.587785},
{0.864188,0.442863,0.238856},
{0.688191,0.587785,0.425325},
{0.809017,0.309017,0.500000},
{0.681718,0.147621,0.716567},
{0.587785,0.425325,0.688191},
{0.955423,0.295242,0.000000},
{1.000000,0.000000,0.000000},
{0.951056,0.162460,0.262866},
{0.850651,-0.525731,0.000000},
{0.955423,-0.295242,0.000000},
{0.864188,-0.442863,0.238856},
{0.951056,-0.162460,0.262866},
{0.809017,-0.309017,0.500000},
{0.681718,-0.147621,0.716567},
{0.850651,0.000000,0.525731},
{0.864188,0.442863,-0.238856},
{0.809017,0.309017,-0.500000},
{0.951056,0.162460,-0.262866},
{0.525731,0.000000,-0.850651},
{0.681718,0.147621,-0.716567},
{0.681718,-0.147621,-0.716567},
{0.850651,0.000000,-0.525731},
{0.809017,-0.309017,-0.500000},
{0.864188,-0.442863,-0.238856},
{0.951056,-0.162460,-0.262866},
{0.147621,0.716567,-0.681718},
{0.309017,0.500000,-0.809017},
{0.425325,0.688191,-0.587785},
{0.442863,0.238856,-0.864188},
{0.587785,0.425325,-0.688191},
{0.688191,0.587785,-0.425325},
{-0.147621,0.716567,-0.681718},
{-0.309017,0.500000,-0.809017},
{0.000000,0.525731,-0.850651},
{-0.525731,0.000000,-0.850651},
{-0.442863,0.238856,-0.864188},
{-0.295242,0.000000,-0.955423},
{-0.162460,0.262866,-0.951056},
{0.000000,0.000000,-1.000000},
{0.295242,0.000000,-0.955423},
{0.162460,0.262866,-0.951056},
{-0.442863,-0.238856,-0.864188},
{-0.309017,-0.500000,-0.809017},
{-0.162460,-0.262866,-0.951056},
{0.000000,-0.850651,-0.525731},
{-0.147621,-0.716567,-0.681718},
{0.147621,-0.716567,-0.681718},
{0.000000,-0.525731,-0.850651},
{0.309017,-0.500000,-0.809017},
{0.442863,-0.238856,-0.864188},
{0.162460,-0.262866,-0.951056},
{0.238856,-0.864188,-0.442863},
{0.500000,-0.809017,-0.309017},
{0.425325,-0.688191,-0.587785},
{0.716567,-0.681718,-0.147621},
{0.688191,-0.587785,-0.425325},
{0.587785,-0.425325,-0.688191},
{0.000000,-0.955423,-0.295242},
{0.000000,-1.000000,0.000000},
{0.262866,-0.951056,-0.162460},
{0.000000,-0.850651,0.525731},
{0.000000,-0.955423,0.295242},
{0.238856,-0.864188,0.442863},
{0.262866,-0.951056,0.162460},
{0.500000,-0.809017,0.309017},
{0.716567,-0.681718,0.147621},
{0.525731,-0.850651,0.000000},
{-0.238856,-0.864188,-0.442863},
{-0.500000,-0.809017,-0.309017},
{-0.262866,-0.951056,-0.162460},
{-0.850651,-0.525731,0.000000},
{-0.716567,-0.681718,-0.147621},
{-0.716567,-0.681718,0.147621},
{-0.525731,-0.850651,0.000000},
{-0.500000,-0.809017,0.309017},
{-0.238856,-0.864188,0.442863},
{-0.262866,-0.951056,0.162460},
{-0.864188,-0.442863,0.238856},
{-0.809017,-0.309017,0.500000},
{-0.688191,-0.587785,0.425325},
{-0.681718,-0.147621,0.716567},
{-0.442863,-0.238856,0.864188},
{-0.587785,-0.425325,0.688191},
{-0.309017,-0.500000,0.809017},
{-0.147621,-0.716567,0.681718},
{-0.425325,-0.688191,0.587785},
{-0.162460,-0.262866,0.951056},
{0.442863,-0.238856,0.864188},
{0.162460,-0.262866,0.951056},
{0.309017,-0.500000,0.809017},
{0.147621,-0.716567,0.681718},
{0.000000,-0.525731,0.850651},
{0.425325,-0.688191,0.587785},
{0.587785,-0.425325,0.688191},
{0.688191,-0.587785,0.425325},
{-0.955423,0.295242,0.000000},
{-0.951056,0.162460,0.262866},
{-1.000000,0.000000,0.000000},
{-0.850651,0.000000,0.525731},
{-0.955423,-0.295242,0.000000},
{-0.951056,-0.162460,0.262866},
{-0.864188,0.442863,-0.238856},
{-0.951056,0.162460,-0.262866},
{-0.809017,0.309017,-0.500000},
{-0.864188,-0.442863,-0.238856},
{-0.951056,-0.162460,-0.262866},
{-0.809017,-0.309017,-0.500000},
{-0.681718,0.147621,-0.716567},
{-0.681718,-0.147621,-0.716567},
{-0.850651,0.000000,-0.525731},
{-0.688191,0.587785,-0.425325},
{-0.587785,0.425325,-0.688191},
{-0.425325,0.688191,-0.587785},
{-0.425325,-0.688191,-0.587785},
{-0.587785,-0.425325,-0.688191}
};


















struct vframe{
	int blank;
	unsigned char minbound[3];
	unsigned char unknown1;
	unsigned char maxbound[3];
	unsigned char unknown2;
	unsigned char *v;
};

struct MDL_FILE{
	char filetype[4];
	int version;
	float xscale,yscale,zscale;
	float xoffset,yoffset,zoffset;
	float radius;
	float f1,f2,f3;
	unsigned num_items;
	unsigned bitmapw;
	unsigned bitmaph;
	unsigned num_vertices;
	unsigned num_triangles;
	unsigned num_frames;
	unsigned blank;
	unsigned char *bitmap;
	unsigned int *vertex;
	unsigned int *triangle;
	struct vframe *frame;
	char filename[128];
};

typedef struct BG_Matrix{
  double m[4][4];
  };

MDL_FILE mdl;

void write_mdl(FILE *out, MDL_FILE *m);
unsigned find_chunk(FILE *, short, unsigned );
double 	BG_Magnitude( BG_3pt *);  		// returns mag of vector
double 	BG_DotProduct( BG_3pt *, BG_3pt *);// returns dot prod.
BG_3pt   BG_CrossProduct( BG_3pt *,  BG_3pt * );
BG_3pt   BG_AddPts( BG_3pt *,  BG_3pt * );
BG_3pt   BG_SubtractPts( BG_3pt *,  BG_3pt * );
BG_3pt   BG_MultiplyPts( BG_3pt *,  BG_3pt * );
void 	BG_Normalize( BG_3pt *);           // normalizes vect
void BG_IdentityMatrix( BG_Matrix * );
void BG_ZeroMatrix( BG_Matrix * );
BG_3pt BG_MatrixVector3( BG_Matrix *, BG_3pt *);
BG_3pt BG_VectorMatrix3( BG_3pt *,BG_Matrix * );
BG_3pt BG_MatrixVector4( BG_Matrix *, BG_3pt *);
BG_Matrix BG_MatrixMult( BG_Matrix *, BG_Matrix *);

void main( int argc, char *argv[])
{
	FILE *in, *out;
	// 3ds parameters
	unsigned char ch;
	unsigned char str[128];
	unsigned int uint,next_chunk;
	long unsigned int chunk_length;
	long unsigned int primary_length;
	long unsigned int object_length;
	long unsigned int main_length;
	long unsigned int main_count;
	long unsigned int count;
	long unsigned int object_count;
	long unsigned int poly_count;
	long unsigned int poly_length;
	int  i,j,k;
	short int sint;
	short int num_vertices;
	float vertex[10000];
	short int num_tris;
	short int v[10000];
	float matrix[4][3];
	// mdl parameters
	unsigned frame=0;

	BG_3pt vect1, vect2,pt1,pt2,pt3;


	char in_name[128];
	char out_name[128];
////////////////////////// some initial mdl stuff

	mdl.filetype[0]='I';
	mdl.filetype[1]='D';
	mdl.filetype[2]='P';
	mdl.filetype[3]='O';

	mdl.version=3;

	mdl.xscale=1.e-3;
	mdl.yscale=1.e-3;
	mdl.zscale=1.e-3;
	mdl.xoffset=0.;
	mdl.yoffset=0.;
	mdl.zoffset=0.;
	mdl.radius=100.;
	mdl.f1=0.;
	mdl.f2=0.;
	mdl.f3=0.;

	mdl.num_items=1;
	mdl.bitmapw=400;
	mdl.bitmaph=200;
	mdl.num_vertices=1;
	mdl.num_triangles=1;
	mdl.num_frames=1;
	mdl.blank=0;

	mdl.bitmap=new (unsigned char)[mdl.bitmapw*mdl.bitmaph];
	for(i=0;i<mdl.bitmapw;i++)
	{
	for(j=0;j<mdl.bitmaph;j++)
	{
		mdl.bitmap[i+j*mdl.bitmapw]=i;
	}
	}
//	mdl.vertex=NULL;
//	mdl.triangle=NULL;

	mdl.frame=new vframe;

	mdl.frame[0].blank=0;
//	mdl.frame[0].minbound[3];
	mdl.frame[0].unknown1=0;
//	mdl.frame[0].maxbound[3];
	mdl.frame[0].unknown2=0;
//	mdl.frame[0].v[];


	sprintf(mdl.filename,"box.mdl");






////////////////// open 3ds file for reading
	sprintf(in_name,"box.3ds");
	in=fopen(in_name,"rb");

	if(in==NULL) exit(1);

	fread(&sint,2,1,in);
	if(sint!=0x4D4D)
	{
		fprintf(stderr,"Not a 3ds file..\n");
		exit(0);
	}
	fread(&primary_length,4,1,in);
	fprintf(stderr,"3ds file. length %u bytes\n",primary_length);

	// find mesh description
	main_length=find_chunk(in,0x3d3d,primary_length);
	if(main_length==0) exit(1);
	if(main_length==1)
	{
		fprintf(stderr,"no mesh found\n");
		exit(1);
	}
	fprintf(stderr,"mesh size: %u bytes\n",main_length);


	count=0;
	while(count+6<main_length)
	{
		fread(&sint,2,1,in);
		count+=2;
		if(feof(in)) return 0;

		fread(&uint,4,1,in);
		count+=4;
		if(feof(in)) return 0;

		// is object?
		if(sint==0x4000)
		{
			printf("object size: %u bytes, name: ",uint);
			i=0;

			fread(&str[0],1,1,in);
			printf("%c",str[0]);
			while((str[i]!=0x00)&&(i<128))
			{
			  i++;
			  fread(&str[i],1,1,in);
			  printf("%c",str[i]);
			}

			printf("\n");
			object_length=uint-i-1;
			object_count=0;
			while(object_count+6<object_length)
			{
				fread(&sint,2,1,in);
				object_count+=2;

				fread(&uint,4,1,in);
				object_count+=4;

				if(sint==0x4100)
				{
					fprintf(stderr,"triangle size: %u bytes\n",uint);

					poly_length=uint;
					poly_count=0;
					while(poly_count+6<poly_length)
					{
						fread(&sint,2,1,in);
						poly_count+=2;
						object_count+=2;

						fread(&uint,4,1,in);
						poly_count+=4;
						object_count+=4;

						if(sint==0x4110)
						{
							printf("Vertex list size: %u bytes\n",uint);
							fread(&num_vertices,2,1,in);
////////////////////////////// num verts
							mdl.num_vertices=(unsigned)num_vertices;
							mdl.vertex=new (unsigned)[num_vertices*3];
							mdl.frame[0].v=new (unsigned char)[num_vertices*4];

							float minv_x,minv_y,minv_z;
							float maxv_x,maxv_y,maxv_z;
							j=0;
							fread(&vertex[j*3],4,3,in);
							printf("%d: %f %f %f\n",j,vertex[j*3],vertex[j*3+1],vertex[j*3+2]);
							//////////////////////////
							minv_x=vertex[j*3];
							minv_y=vertex[j*3+1];
							minv_z=vertex[j*3+2];
							maxv_x=vertex[j*3];
							maxv_y=vertex[j*3+1];
							maxv_z=vertex[j*3+2];

							mdl.vertex[j*3]=0;
							mdl.vertex[j*3+1]=0;
							mdl.vertex[j*3+2]=0;
							for(j=1;j<num_vertices;j++)
							{
								fread(&vertex[j*3],4,3,in);
								printf("%d: %f %f %f\n",j,vertex[j*3],vertex[j*3+1],vertex[j*3+2]);

								if(vertex[j*3]<minv_x)
								minv_x=vertex[j*3];
								if(vertex[j*3+1]<minv_y)
								minv_y=vertex[j*3+1];
								if(vertex[j*3+2]<minv_z)
								minv_z=vertex[j*3+2];

								if(vertex[j*3]>maxv_x)
								maxv_x=vertex[j*3];
								if(vertex[j*3+1]>maxv_y)
								maxv_y=vertex[j*3+1];
								if(vertex[j*3+2]>maxv_z)
								maxv_z=vertex[j*3+2];

///////////////////////////////// must move
								mdl.vertex[j*3]=0;
								mdl.vertex[j*3+1]=0;
								mdl.vertex[j*3+2]=0;
							}
							double spanx,spany,spanz;
							spanx=maxv_x-minv_x;
							spany=maxv_y-minv_y;
							spanz=maxv_z-minv_z;
							double scalex, scaley, scalez;
							scalex=spanx/255.0;
							scaley=spany/255.0;
							scalez=spanz/255.0;
							double offsetx, offsety,offsetz;
							offsetx=minv_x;
							offsety=minv_y;
							offsetz=minv_z;

							mdl.xoffset=minv_x;
							mdl.yoffset=minv_y;
							mdl.zoffset=minv_z;

							mdl.xscale=scalex;
							mdl.yscale=scaley;
							mdl.zscale=scalez;
							mdl.frame[0].minbound[0]=(unsigned char)0;
							mdl.frame[0].minbound[1]=(unsigned char)0;
							mdl.frame[0].minbound[2]=(unsigned char)0;
							mdl.frame[0].maxbound[0]=(unsigned char)255;
							mdl.frame[0].maxbound[1]=(unsigned char)255;
							mdl.frame[0].maxbound[2]=(unsigned char)255;

							for(j=0;j<num_vertices;j++)
							{

								mdl.frame[0].v[j*4]=(unsigned char)((vertex[j*3]-minv_x)/scalex);
								mdl.frame[0].v[j*4+1]=(unsigned char)((vertex[j*3+1]-minv_y)/scaley);
								mdl.frame[0].v[j*4+2]=(unsigned char)((vertex[j*3+2]-minv_z)/scalez);
								mdl.frame[0].v[j*4+3]=255;


							}





						}
						else if(sint==0x4120)
						{
							printf("Points list size: %u bytes\n",uint);
							fread(&num_tris,2,1,in);
///////////////////////////// number of polys
							mdl.num_triangles=(unsigned)num_tris;
							mdl.triangle= new (unsigned)[num_tris*4];

							for(j=0;j<num_tris;j++)
							{
								fread(&v[j*4],2,4,in);
								printf("%d: %hd %hd %hd\n",j,v[j*4],v[j*4+1],v[j*4+2]);

/////////////////////////////// fix also
								mdl.triangle[j*4]=1;
								mdl.triangle[j*4+1]=(unsigned)v[j*4];
								mdl.triangle[j*4+2]=(unsigned)v[j*4+2];
								mdl.triangle[j*4+3]=(unsigned)v[j*4+1];

							}
							goto jumphere;
						}

						else if(sint==0x4160)
						{
							printf("Matrix size: %u bytes\n",uint);
							fread(matrix[0],4,3,in);
							fread(matrix[1],4,3,in);
							fread(matrix[2],4,3,in);
							fread(matrix[3],4,3,in);
							printf("%f %f %f %f\n",matrix[0][0],matrix[0][1],matrix[0][2]);
							printf("%f %f %f %f\n",matrix[1][0],matrix[1][1],matrix[1][2]);
							printf("%f %f %f %f\n",matrix[2][0],matrix[2][1],matrix[2][2]);
							printf("%f %f %f %f\n",matrix[3][0],matrix[3][1],matrix[3][2]);
		//					goto jumphere;
						}
						else
						{
							fseek(in,uint-6, SEEK_CUR);
						}
						poly_count+=uint-6;
						object_count+=uint-6;
					}


				}
				else
				{
					fseek(in,uint-6, SEEK_CUR);
					object_count+=uint-6;
				}
				if(feof(in)) return 0;
			}

	   //		fseek(in,uint-6-i-1, SEEK_CUR);
	   //		count+=uint-6-i-1;

		}
		else
		{
			fseek(in,uint-6, SEEK_CUR);
			count+=uint-6;
		}
		if(feof(in)) return 0;
//		if(count>=max) return 1;
	}
jumphere:
	fclose(in);
	///////////////// done with 3ds file


	/////////////// find normals (surface)
		BG_3pt *normal, vnormal;
		normal = new (BG_3pt)[mdl.num_triangles];
//		vnormal = new (BG_3pt)[mdl.num_vertices];
		for(j=0;j<mdl.num_triangles; j++)
		{

			pt1.x=(double)vertex[mdl.triangle[j*4L+1L]*3 ];
			pt1.y=(double)vertex[mdl.triangle[j*4L+1L]*3+1 ];
			pt1.z=(double)vertex[mdl.triangle[j*4L+1L]*3+2 ];
			pt2.x=(double)vertex[mdl.triangle[j*4L+2L]*3 ];
			pt2.y=(double)vertex[mdl.triangle[j*4L+2L]*3+1 ];
			pt2.z=(double)vertex[mdl.triangle[j*4L+2L]*3+2 ];
			pt3.x=(double)vertex[mdl.triangle[j*4L+3L]*3 ];
			pt3.y=(double)vertex[mdl.triangle[j*4L+3L]*3+1 ];
			pt3.z=(double)vertex[mdl.triangle[j*4L+3L]*3+2 ];

			vect1=BG_SubtractPts(&pt2,&pt1);
			vect2=BG_SubtractPts(&pt3,&pt1);
			normal[j]=BG_CrossProduct(&vect2,&vect1);
			BG_Normalize(&normal[j]);
		}
	/////////////////// finding vertex normals
	double avex,avey,avez;
	int norm_count;

		for(j=0;j<mdl.num_vertices; j++)
		{
			avex=avey=avez=0.0;
			norm_count=0;
			for(i=0; i<mdl.num_triangles; i++)
			{

				if((j==mdl.triangle[i*4L+1L])||(j==mdl.triangle[i*4L+2L])||(j==mdl.triangle[i*4L+3L]) )
				{
					avex+=normal[i].x;
					avey+=normal[i].y;
					avez+=normal[i].z;
					norm_count++;
				}

			}
			vnormal.x=avex/(double)norm_count;
			vnormal.y=avey/(double)norm_count;
			vnormal.z=avez/(double)norm_count;
			k=0; /// this is the index!
			double dotted_val, hi_dot;
			hi_dot=BG_DotProduct(&norm_table[0],&vnormal);

			for(i=1; i<162; i++)
			{

				dotted_val=BG_DotProduct(&norm_table[i],&vnormal);
				if(dotted_val>hi_dot)
				{
					hi_dot=dotted_val;
					k=i;
				}

			}

			mdl.frame[0].v[j*4+3]=(unsigned char)k;

		}








	sprintf(out_name,"box.mdl");
	out=fopen(out_name,"wb");

	if(out==NULL) {printf("error\n"); exit(1);}

	write_mdl(out,&mdl);

	fclose(out);
	fprintf(stderr,"Ok, all done.\n");
	fprintf(stderr,"3ds2mdl by brian martin 1996\n");


}






unsigned find_chunk(FILE *f, short flag, unsigned max)
{

	short sint;
	unsigned uint;
	unsigned count;

	count=0;

	while(1)
	{
		fread(&sint,2,1,f);
		count+=2;
		if(feof(f)) return 0;
		if(count>=max) return 1;

		fread(&uint,4,1,f);
		count+=4;
		if(feof(f)) return 0;
		if(count>=max) return 1;

		if(sint==flag) return uint;
		fseek(f,uint-6, SEEK_CUR);
		count+=uint-6;

		if(feof(f)) return 0;
		if(count>=max) return 1;
	}


}
void write_mdl(FILE *out, MDL_FILE *m)
{
	unsigned i,j,k;
	unsigned empty=0;

	fwrite(mdl.filetype,4,1,out);
	fwrite(&mdl.version,4,1,out);
	fwrite(&mdl.xscale,4,1,out);
	fwrite(&mdl.yscale,4,1,out);
	fwrite(&mdl.zscale,4,1,out);
	fwrite(&mdl.xoffset,4,1,out);
	fwrite(&mdl.yoffset,4,1,out);
	fwrite(&mdl.zoffset,4,1,out);
	fwrite(&mdl.radius,4,1,out);
	fwrite(&mdl.f1,4,1,out);
	fwrite(&mdl.f2,4,1,out);
	fwrite(&mdl.f3,4,1,out);

	fwrite(&mdl.num_items,4,1,out);
	fwrite(&mdl.bitmapw,4,1,out);
	fwrite(&mdl.bitmaph,4,1,out);
	fwrite(&mdl.num_vertices,4,1,out);
	fwrite(&mdl.num_triangles,4,1,out);
	fwrite(&mdl.num_frames,4,1,out);
	fwrite(&mdl.blank,4,1,out);

	for(k=0;k<mdl.num_items;k++)
	{
		fputc(0,out);
		fputc(0,out);
		fputc(0,out);
		fputc(0,out);

		for(j=0;j<mdl.bitmaph;j++)
		{
			for(i=0;i<mdl.bitmapw;i++)
			{
				fputc(mdl.bitmap[(i+mdl.bitmapw*(j+k*mdl.bitmaph))],out);
			}
		}
	}


	for(i=0;i<mdl.num_vertices;i++)
	{
		fwrite(mdl.vertex+i*3L,4,1,out);
		fwrite(mdl.vertex+i*3L+1L,4,1,out);
		fwrite(mdl.vertex+i*3L+2L,4,1,out);

	}

	for(i=0;i<mdl.num_triangles;i++)
	{
		fwrite(mdl.triangle+i*4L,4,1,out);
		fwrite(mdl.triangle+i*4L+1L,4,1,out);
		fwrite(mdl.triangle+i*4L+2L,4,1,out);
		fwrite(mdl.triangle+i*4L+3L,4,1,out);
	}


	for(j=0; j<mdl.num_frames;  j++)
	{

		fwrite(&mdl.frame[j].blank,4,1,out);
		fwrite(mdl.frame[j].minbound,1,3,out);

		fwrite(&mdl.frame[j].unknown1,1,1,out);
		fwrite(mdl.frame[j].maxbound,1,3,out);
		fwrite(&mdl.frame[j].unknown2,1,1,out);

		for(i=0;i<mdl.num_vertices;i++)
		{
			fwrite(mdl.frame[j].v+i*4,1,1,out);
			fwrite(mdl.frame[j].v+i*4+1,1,1,out);
			fwrite(mdl.frame[j].v+i*4+2,1,1,out);
			fwrite(mdl.frame[j].v+i*4+3,1,1,out);
		}
	}

}
double BG_DotProduct( BG_3pt *a,  BG_3pt *b )
{
	double c;
	c=a->x*b->x+a->y*b->y+a->z*b->z;
	return c;
}


BG_3pt BG_CrossProduct( BG_3pt *a,  BG_3pt *b )
{
	BG_3pt c;
	c.x=(a->y*b->z) - (a->z*b->y);
	c.y=(a->z*b->x) - (a->x*b->z);
	c.z=(a->x*b->y) - (a->y*b->x);
	return c;
}


BG_3pt BG_AddPts( BG_3pt *a,  BG_3pt *b )
{
	BG_3pt c;
	c.x=a->x + b->x;
	c.y=a->y + b->y;
	c.z=a->z + b->z;
	return c;
}

BG_3pt BG_SubtractPts( BG_3pt *a,  BG_3pt *b )
{
	BG_3pt c;
	c.x=a->x - b->x;
	c.y=a->y - b->y;
	c.z=a->z - b->z;
	return c;
}

BG_3pt BG_MultiplyPts( BG_3pt *a,  BG_3pt *b )
{
	BG_3pt c;
	c.x=a->x * b->x;
	c.y=a->y * b->y;
	c.z=a->z * b->z;
	return c;
}

double BG_Magnitude( BG_3pt *a )
{
	double mag;
	mag = BG_DotProduct(a,a);
	mag = sqrt(mag);
	return mag;
}

void BG_Normalize( BG_3pt *a )
{
	double b, c;

	b = BG_Magnitude( a );
	if ( b != 0.0 )
	{
		c = 1.0/b;
		a->x*=c;
		a->y*=c;
		a->z*=c;
	}
}

